package main

import (
	"fmt"
	"io/ioutil"
	"math/rand"
	"os"
	"strings"
	"time"
)

// Create a new type of 'deck'
// which is a slice of strings

type deck []string //****this new deck type we're creating kind of extends or borrows all the behaviour of a slice of string

func newDeck() deck {
	cards := deck{}

	cardSuits := []string{"Spades", "Hearts", "Diamomds", "Clubs"}
	cardValues := []string{"Ace", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "King", "Queen", "Jack"}

	for _, suit := range cardSuits {
		for _, value := range cardValues {
			cards = append(cards, value+" of "+suit)
		}
	}

	return cards
}

// neeche jo func k baad () usko receiver bolte
func (d deck) print() {
	for i, card := range d {
		fmt.Println(i, card)
	}
}

//Deal fn

func deal(d deck, handSize int) (deck, deck) {
	return d[:handSize], d[handSize:]
}

// func to convert into string
func (d deck) toString() string {
	return strings.Join([]string(d), ",")
}

//save to file

func (d deck) saveToFile(filename string) error {
	return ioutil.WriteFile(filename, []byte(d.toString()), 0666)
}

//func to read, deck in first line is return type that we specified, then bs is byte slice and err is error
func newDeckFromFile(filename string) deck {
	bs, err := ioutil.ReadFile(filename)
	if err != nil {
		// Option #1 log the error and return a call to newDeck()
		// Option #2 Log the error and entirely quit the program
		fmt.Println("Error:", err)
		os.Exit(1)
	}

	s := strings.Split(string(bs), ",")
	return deck(s)
}

//Shuffling function
func (d deck) shuffle() {
	source := rand.NewSource(time.Now().UnixNano())
	r:= rand.New(source)


	for i := range d {
		newPosition := r.Intn(len(d) - 1)

		d[i], d[newPosition] = d[newPosition], d[i]
	}
}
