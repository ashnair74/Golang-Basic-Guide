package main


func main() {

	//var card string = "Ace of Spades"
	// card := newCard() // sirf ek baar use krte := to initialize the var baar baar jaroorat nhi
	// //example: card = "Five of Diamonds"
	// fmt.Println(card)

	// (example of slice)
	//cards := []string{"Ace of Diamonds", newCard()} //yaha pe slice of string banaya tha usko deck se replace kr diya
	//cards := deck{"Ace of Diamonds", newCard()}

	// cards := newDeck()
	// cards.saveToFile("my_cards")
	//fmt.Println(cards.toString())

	//cards = append(cards, "Six of Spades")

	// (example of iterating over a closed set)
	// for i, card := range cards{
	// 	fmt.Println(i, card)
	// }

	//	cards.print() // yaha apan ne upar ka for loop hata diya aur usko func call krdiya jo deck.go me hai
	//fmt.Println(cards)

	// hand, remainingCards := deal(cards, 5)
	// hand.print()
	// remainingCards.print()

	//testing newDeckFromFile
	// cards:= newDeckFromFile("my_cards")
	//cards.print()

	//testing shuffle
	cards := newDeck()
	cards.shuffle()
	cards.print()
}

// func newCard() string {
// 	return "Five of Diamonds"
// }
