package main

import "fmt"

type person struct {
	firstName string
	lastName  string
	contact   contactInfo
}

type contactInfo struct {
	email   string
	zipCode string
}

func main() {
	// alex := person{firstName: "Alex", lastName: "Anderson"}
	// fmt.Println(alex)

	// var andy person
	// fmt.Println(andy)
	// fmt.Printf("%+v",andy)

	// var cindy person
	// cindy.firstName = "cindy"
	// cindy.lastName = "anderson"
	// fmt.Println(cindy)

	jim := person{
		firstName: "jim",
		lastName:  "party",
		contact: contactInfo{
			email:   "abc.com",
			zipCode: "12133",
		},
	}
	//fmt.Printf("%+v",jim)  //or
	//jimpointer := &jim
	//jimpointer.updateName("jimmy")
	jim.updateName("jimmy")
	jim.print()
}

func (pointerToPerson *person) updateName(newFirstName string) {
	(*pointerToPerson).firstName = newFirstName
}

func (p person) print() {
	fmt.Printf("%+v", p)
}

